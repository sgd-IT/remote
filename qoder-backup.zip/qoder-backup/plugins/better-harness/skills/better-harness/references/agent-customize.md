# Agent Customize Evidence

Consume supplied Step 1 configured-agent evidence without rerunning it; return independent candidates. The lead owns final judgment.

## Boundary

- Inspect Rules/`AGENTS.md`, Skills, MCP/connectors, Memory/knowledge, Custom
  Agents, Hooks/gates/permissions, Commands, Workflows, and Plugins.
- Project assets and selected-workspace Qoder Memory-title metadata are in scope.
  User/global or Codex Memory, plugin marketplace metadata, and all Memory bodies
  require explicit lead authority.
- Do not inspect application code, Session facts, another brief, Memory bodies,
  private caches, transcripts, databases, or provider internals.
- Do not run Session/Harness analysis, asset scanners, cleanup, apply, or
  mutation commands. A failed Step 1 envelope stays unavailable.
- Open at most three assets in quick or five in normal mode; metadata rows do not consume the limit.

## Interpret the Baseline

Counts route inspection; they do not create findings or scores. Active coverage is provider-owned; other assets stay source-only.

- Zero project Skills routes repeated-work review; other capabilities may own it.
- Many Skills route trigger, overlap, and maintainability review.
- Many Memories require exact/near duplicate, conflict, provenance, staleness,
  and retrieval-value review. Count never earns Learning Capture credit.
- MCP count routes capability, least-privilege, and owner inspection. A missing
  owner stays coverage-map state, not a potential finding without an explicit
  governing requirement or deterministic present defect.
- Multiple Plugins require canonical-name, capability-fingerprint, version,
  replacement, and child-asset ownership review.
- A short `AGENTS.md` is not defective by length. Check whether it routes to
  current owners and states the few always-needed constraints. A long file is
  not defective without model-visible load or maintenance impact.

The deterministic `asset-integrity` envelope takes precedence over raw counts:

- route authorized lint errors before counts or similarity, then corroborate the target and canonical identity. A lint label never waives finding eligibility;
  a detector label cannot turn an inspected placeholder or example into a secret or exposure;
- always return exact same-scope Memory-title collisions and verified Plugin
  name/capability overlaps as governance candidates with bounded evidence;
- treat near-title and plugin-family similarity as manual review leads only;
- never infer duplicate bodies, conflict, staleness, runtime cost, or removal
  authority from metadata similarity;
- inspect the smallest safe owner needed to corroborate conflict, replacement,
  stale truth, shadowing, or routing impact.

Account for every surface as inspected, inventory-only, unavailable, or not
applicable; never omit one. This ledger is not a finding schema, and metadata
rows do not consume the asset-open limit.
If selected-workspace Qoder Memories are nonzero but integrity is unavailable,
return a blocking evidence condition; never call them clean or unobserved.

## Review Quality and Ownership

For the few task-relevant assets, keep these axes separate:

- **Presence:** configured, resolved-active, absent-in-scope, or unavailable.
- **Content:** relevant, current, discoverable, executable, maintainable, or not
  inspected.
- **Use:** routed and applied in the same Task Episode; a file read, invocation
  name, loaded prompt, or count does not prove use.
- **Outcome:** effective only after a comparable later outcome without a
  guardrail regression.

Load only the matching one-hop practice: [Rules/AGENTS.md](../../../references/agent-customize/agents-md-review.md), [Skill quality](../../../references/agent-customize/skill-review.md),
[Skill discovery](../../../references/agent-customize/skill-discovery.md), [MCP](../../../references/agent-customize/mcp-review.md), [Memory](../../../references/agent-customize/memory-review.md),
[Custom Agents](../../../references/agent-customize/custom-agents-review.md),
or [Hooks](../../../references/agent-customize/hooks-review.md). Use
[Knowledge Assets](../../../references/agent-customize/knowledge-assets-review.md)
for cross-surface use/coverage and
[Global Assets](../../../references/agent-customize/global-assets.md)
for Plugins, Commands, Workflows, provider scope, and platform-specific routes.
These references guide evidence; they do not expand authority or asset limits.

For Skills, inspect trigger quality, procedural content, routing, overlap, and
available use evidence. For Memory, positive value requires:
`exists -> retrieved -> relevant -> applied -> later outcome improved`.
Before proposing any future Skill or Memory, the lead must check for an
observed, built-in, configured, or extendable owner and deduplicate first.

## Build the Asset Coverage Map

Inventory does not reveal what knowledge is missing. For each inspected owner
chain, summarize only what its evidence can support:

- provider and project/user/plugin scope, canonical owner, and active or
  shadowed version relationship;
- trigger, lookup, or routing surface and the task/procedure family it claims;
- provenance and freshness boundary, plus deterministic integrity candidates;
- `Presence`, `Content`, `Use`, and `Outcome` state without collapsing them.

For Memory, distinguish exact-title collision, possible semantic overlap,
conflict/staleness, demonstrated coverage, and an unknown coverage area. One
exact duplicate title does not imply that other Memories are healthy, useful,
or complete. Do not infer a missing Memory from inventory alone; only the lead
may identify a coverage gap after joining repeated Session knowledge demand
with this map and current project truth. Never return user-home Memory paths or titles.
Keep bounded counts in Qoder `canvas.json`, not prompts, `findings.json`, findings, or scores.

For Plugins, map the distributed Skills, MCPs, apps, Commands, and Workflows to
their canonical package and version. Separate name overlap, capability overlap,
replacement, shadowing, and coexisting complementary routes. Installation or
configuration proves availability only, not selection, invocation, relevance,
or outcome value.

## Return

Write a compact Markdown brief in the user's language. Include scope and
authority, the important inventory facts, inspected owner chains, deterministic
integrity results, the bounded asset coverage map, runtime-use limits, and
only potential findings supported by the supplied evidence.

Express potential findings naturally; no fixed fields or JSON schema are
required. Each must state enough evidence and uncertainty for the lead to judge
it. Keep absent-owner or absent-asset observations in the coverage map unless
an explicit requirement or deterministic present defect supports a candidate.
Keep the brief compact and never fill a quota. Do not assign final severity,
score, repair, cleanup, or recommendation. End with claims the lead must not make.
